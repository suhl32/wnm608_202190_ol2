<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Account</title>	

	<?php include "parts/meta.php"; ?>

</head>
<body>

	
	<?php include "parts/navbar.php"; ?>
	<div class="container">
		<div class="card soft">
			<p>Name:</p>
			<p>Address</p>
			<p>Email</p>
			<p>Phone Number</p>
			<p>My Purchases</p>
		</div>
	</div>

			 
</body>

	<?php include "parts/footer.php"; ?>	

</html>