<?php

function MYSQLIAUTH() {
	return [
		"localhost",
		"suhl32_wmn608",
		"suhl32_wmn608",
		"suhl32_wmn608"
	];
} 

function PDOAuth() {
	return [
		"mysql:host=localhost;dbname=suhl32_wmn608", // host name and database name
		"suhl32_wmn608", // mysql user name
		"suhl32_wmn608", // mysql user password
		[PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"]
	];
}

?>