<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Dog Breed</title>

	<?php include "parts/meta.php"; ?>

</head>
<body>

	<?php include "parts/navbar.php"; ?>

	<div class="container">
	<div class="card soft">
		<h2>Dog Breed</h2>

		<p>This is dog # <?= $_GET['id'] ?></p>
	</div>
	</div>













	
</body>

	<?php include "parts/footer.php"; ?>

</html>