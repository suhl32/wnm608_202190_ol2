<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cart</title>	

	<?php include "parts/meta.php"; ?>

</head>
<body>

	
	<?php include "parts/navbar.php"; ?>

	<div class="container">
		<div class="card soft">
			<p>cart info</p>
			<button>Purchase</button>
		</div>
	</div>

			 
</body>

	<?php include "parts/footer.php"; ?>	

</html>