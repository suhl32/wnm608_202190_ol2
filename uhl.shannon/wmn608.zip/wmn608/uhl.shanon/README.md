# Shannon Uhl

## Relevant Links
- http://shannonuhl.com
- http://shannonuhl.com/wmn608_202190_0l2/uhl.shannon/wmn608/uhl.shanon
- http://shannonuhl.com/wmn608_202190_ol2/uhl.shannon/wmn608/uhl.shanon/styleguide/index.html
- http://shannonuhl.com/wmn608_202190_0l2/uhl.shannon/wmn608/uhl.shanon/lib/css/styleguide
- https://shannonuhl.com/wmn608/uhl.shanon/notes/reading_data.php
- https://shannonuhl.com/wmn608/uhl.shanon/admin/users.php
