# Shannon Uhl

## Relevant Links
- http://shannonuhl.com
- http://shannonuhl.com/wmn608/uhl.shanon
- http://shannonuhl.com/wmn608/uhl.shanon/styleguide/index.html
- http://shannonuhl.com/wmn608/uhl.shanon/lib/css/styleguide
- http://shannonuhl.com/wmn608/uhl.shanon/admin/index.php

## Extra Links

- http://shannonuhl.com/wmn608/uhl.shanon/admin/users.php
- http://shannonuhl.com/wmn608/uhl.shanon/notes
- http://shannonuhl.com/wmn608/uhl.shanon/notes/reading_data.php