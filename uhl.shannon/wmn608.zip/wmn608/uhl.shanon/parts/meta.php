<meta name="viewport" content="width=device-width">

<base href="https://shannonuhl.com/wmn608/uhl.shanon/index.php">

	<link rel="stylesheet" href="lib/css/styleguide.css">
	<link rel="stylesheet" href="lib/css/gridsystem.css">
	<link rel="stylesheet" href="css/storetheme.css">