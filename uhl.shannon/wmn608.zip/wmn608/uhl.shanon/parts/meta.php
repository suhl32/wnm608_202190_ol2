<meta name="viewport" content="width=device-width">

<base href="https://shannonuhl.com/wmn608/uhl.shanon/">
	
	<link rel="stylesheet" href="css/storetheme.css">
	<link rel="stylesheet" href="lib/css/styleguide.css">
	<link rel="stylesheet" href="lib/css/gridsystem.css">
	

	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>