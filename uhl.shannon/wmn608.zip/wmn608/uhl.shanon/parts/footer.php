<div class="footer">

	<div class="flex-stretch"></div>
			<nav class="nav nav-flex flex-none">
				<ul class="container display-flex">
					
					<li><a href="about.php">About Dog & Co.</a></Li>
					<li><a href="contact.php">Contact Us</a></Li>
				</ul>
			</nav>
		</div>
</div>	