<?php 

include "../lib/php/functions.php";

$empty_product = (object)[
	"breed"=>"",
	"description"=>"",
	"price"=>"",
	"category"=>"",
	"size"=>"",
	"thumbnail"=>"",
	"images"=>"",
	"quantity"=>"",
];


// TEMPLATES
function productListItem($r,$o) {
	return $r.<<<HTML
<div><a href="{$_SERVER['PHP_SELF']}?id=$o->id">$o->breed</a></div>
HTML;
}



function showProductPage($o) {
$addoredit = $id == "new" ? "Add" : "Edit";
$createorupdate = $id == "new" ? "create" : "update";
$images = array_reduce(explode(",", $o->images),function($r,$o){return $r."<img src='/../$o'>";});

// heredoc 
$display = <<<HTML 
<div>
	<h2>$o->breed</h2>
	<div class="form-control">
		<label class="form-label">Price</label>
		<span>$dollar;$o->price</span>
	</div>
	<div class="form-control">
		<label class="form-label">Category</label>
		<span>$o->category</span>
	</div>
	<div class="form-control">
		<label class="form-label">Description</label>
		<span>$o->$description</span>
	</div>
	<div class="form-control">
		<label class="form-label">Thumbnail</label>
		<span class="images-thumbs"><img src ='/../$o->thumbnail'></span>
	</div>
	<div class="form-control">
		<label class="form-label">Other Images</label>
		<span class="images-thumbs">$images</span>
	</div>
</div>
HTML;
	
$form = <<<HTML
<form method="post" action="{$_SERVER['PHP_SELF']}?id=$id&action=$createorupdate">
	<h2>$addoredit User</h2>
	<div class="form-control">
		<label class="form-label" for="user-breed">Breed</label>
		<input class="form-input" name="user-breed" id="user-breed" type="text" value="$o->breed" placeholder="Enter the Product Breed">
	</div>
	<div class="form-control">
		<label class="form-label" for="user-type">Type</label>
		<input class="form-input" name="user-type" id="user-type" type="text" value="$o->type" placeholder="Enter the Product Type">
	</div>
	<div class="form-control">
		<label class="form-label" for="user-address">Address</label>
		<input class="form-input" name="user-address"  id="user-address"type="text" value="$o->address" placeholder="Enter the Product Address">
	</div>
	<div class="form-control">
		<label class="form-label" for="user-phone">Phone Number</label>
		<input class="form-input" name="user-phone" id="user-phone" type="text" value="$o->images" placeholder="Enter the Product Phone Number">
	</div>
	<div class="form-control">
		<input class="form-button" type="submit" value="Save Changes">
	</div>
</form>
HTML;

$output = $id == "new" ? "<div class='card soft'>$form</div>" :
	"<div class= 'grid gap'>
		<div class='col-xs-12 col-md-7'><div class='card soft'>$display</div></div>
		<div class='col-xs-12 col-md-5'><div class='card soft'>$form</div></div>
	</div>
	";

$delete = $id == "new" ? : "<a href='{$_SERVER['PHP_SELF']}?id=$id&action=delete'>Delete</a>";

echo <<<HTML
<div class ="card soft">
<nav class="display-flex">
		<div class="flex-stretch"><a href="{$_SERVER['PHP_SELF']}">Back</a></div>
		<div class="flex-none">$delete</div>
</nav>
</div>
$output
HTML;
}


?>

 

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Product Admin Page</title>

	<?php include "../parts/meta.php"; ?>

</head>
<body>

	<header class="navbar">
		<div class="container display-flex">
			<div class="flex-none">
				<h1>Product Admin</h1>
			</div>
			<div class="flex-stretch"></div>
			<nav class="nav nav-flex flex-none">
				<ul>
					<li><a href="<?= $_SERVER['PHP_SELF'] ?>">Product List</a></li>
					<li><a href="<?= $_SERVER['PHP_SELF'] ?>?id=new">Add New Product</a></li>
				</ul>
			</nav>
		</div>
	</header>

	<div class="container">

		<?php  

		if(isset($_GET['id'])) {
			showProductPage(
				$_GET['id']=="new" ?
					$empty_product :
					makeQuery(makeConn(),"SELECT * FROM `products` WHERE `id`=".$_GET['id'])[0]
			);
			// showProductPage();
		} else {

		?>

		<h2>Product List</h2>
		<div class="card soft">

		<?php 

		$result = makeQuery(makeConn(),"SELECT * FROM `products`");

		echo array_reduce($result, 'productListItem');

		?>

		</div>

		<?php } ?>




	</div>	
</body>